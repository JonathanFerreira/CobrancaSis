<?php
App::uses('UploadBehavior', 'Upload.Model/Behavior');

class FileGrabberBehavior extends UploadBehavior {

}
